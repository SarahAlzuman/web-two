
/**********************************log in page script***************************************************** */


function pagechange(event) {
    event.preventDefault(); //3ashan not chnage unless email w pass mawjood w asln fi shart user type 

    var userType = document.querySelector('input[name="userty"]:checked');

    if (userType) {
        if (userType.value === "client") {
            window.location.href = "home.html";  //the person with client page add ur link here
        } else if (userType.value === "des") {
            window.location.href = "designer-homepage.html"; //the person with designer page add ur link here
        }
    } else {
        alert("Please select a user type!");
    }
}




/***************************************sign up ************************************************************/
function showForm(formId) {
   
    document.getElementById('clientForm').style.display = 'none';
    document.getElementById('designerForm').style.display = 'none';

    
    document.getElementById(formId).style.display = 'block';
}

function submitForm(event, formId, redirectFunction) {
    event.preventDefault(); // Prevent default form submission

    alert('Form submitted successfully!');

   
    window[redirectFunction]();
}

function clientpage(){
    window.location.href = "home.html";  //the person with client page add ur link here
}

function despage(){
    window.location.href = "designer-homepage.html"; //the person with designer page add ur link here
}